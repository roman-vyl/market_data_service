# Full runtime cumulative patch

Built directly against `repo_snapshot(2).zip`. It includes all uninstalled sandbox work since that snapshot:

- WebSocket adapter/connector/confirmed-candle ingestion;
- realtime supervisor and bounded REST recovery coordinator;
- updated WebSocket OpenSpec architecture;
- runtime settings, startup reconciliation, realtime dispatch, status projection, HTTP health/readiness, graceful shutdown;
- `market-data-service serve` entrypoint;
- Docker/compose runtime configuration;
- runtime OpenSpec reconciliation;
- tests and documentation.

Sandbox verification:

```text
ruff: PASS
mypy: PASS (104 source files)
pytest: 177 passed
production files over 220 lines: 0
```

Two OpenSpec tasks remain intentionally open: full process-level fake REST+WebSocket matrix and Docker restart smoke. The existing fake historical and realtime matrices plus runtime settings/startup/status/HTTP tests pass independently.
