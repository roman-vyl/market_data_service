#!/usr/bin/env bash
set -euo pipefail
TARGET="/Users/mcroma/BBB_project/market_data_service"
DRY_RUN=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --dry-run) DRY_RUN=1; shift;;
    *) echo "Unknown argument: $1" >&2; exit 2;;
  esac
done
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 - "$PKG_DIR" "$TARGET" "$DRY_RUN" <<'PY'
import hashlib,json,shutil,sys,time
from pathlib import Path
pkg=Path(sys.argv[1]); target=Path(sys.argv[2]); dry=bool(int(sys.argv[3]))
manifest=json.loads((pkg/'manifest.json').read_text())
if not (target/'pyproject.toml').exists() or not (target/'src/market_data_service').exists():
    raise SystemExit(f'Not a market_data_service repo: {target}')
def sha(p):
    h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()
errors=[]
for rel,expected in manifest['base_files'].items():
    p=target/rel
    if not p.exists(): errors.append(f'missing base file: {rel}')
    elif sha(p)!=expected: errors.append(f'base hash mismatch: {rel}')
for rel in manifest['added']:
    if (target/rel).exists(): errors.append(f'added file already exists: {rel}')
if errors:
    print('Compatibility check FAILED:')
    print('\n'.join(' - '+e for e in errors))
    raise SystemExit(1)
print(f'Target: {target}')
print(f"Replace: {len(manifest['changed'])}; add: {len(manifest['added'])}; delete: {len(manifest['deleted'])}")
if dry:
    print('DRY RUN PASS: no files changed')
    raise SystemExit(0)
backup=target.parent/'.market_data_service_patch_backups'/f'full-runtime-{time.strftime("%Y%m%d-%H%M%S")}'
for rel in manifest['changed']+manifest['deleted']:
    src=target/rel; dst=backup/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
for rel in manifest['changed']+manifest['added']:
    src=pkg/'payload'/rel; dst=target/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
for rel in manifest['deleted']:
    p=target/rel
    if p.exists(): p.unlink()
print(f'Installed. Backup: {backup}')
PY
