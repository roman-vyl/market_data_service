#!/usr/bin/env bash
set -euo pipefail
TARGET="/Users/mcroma/BBB_project/market_data_service"
NETWORK_SMOKE=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) TARGET="$2"; shift 2;;
    --network-smoke) NETWORK_SMOKE=1; shift;;
    *) echo "Unknown argument: $1" >&2; exit 2;;
  esac
done
cd "$TARGET"
PATH=.venv/bin:$PATH make verify
if [[ "$NETWORK_SMOKE" -eq 1 ]]; then
  PATH=.venv/bin:$PATH python3 -m market_data_service smoke-websocket --timeout-seconds 90
fi
